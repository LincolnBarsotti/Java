package med.voll.api.medico;

/**
 * @author Lincoln
 */
public enum Especialidade {
    ORTOPEDIA,
    CARDIOLOGIA,
    GINECOLOGIA,
    DERMATOLOGIA;
}
