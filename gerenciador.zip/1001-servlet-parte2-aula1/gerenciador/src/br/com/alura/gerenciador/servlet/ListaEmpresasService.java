/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package br.com.alura.gerenciador.servlet;

import br.com.alura.gerenciador.modelo.Banco;
import br.com.alura.gerenciador.modelo.Empresa;
import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.google.gson.Gson;
import com.thoughtworks.xstream.XStream;
/**
 *
 * @author marco
 */
@WebServlet(name = "ListaEmpresasService", urlPatterns = {"/empresas"})
public class ListaEmpresasService extends HttpServlet {

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //           JSON
        List<Empresa> empresas = new Banco().getEmpresas();
        
        String valor = request.getHeader("Accept");
//        if(valor.contains("json")){
        Gson gson = new Gson();
        String json = gson.toJson(empresas);
        
        response.setContentType("application/json");
        
        response.getWriter().print(json);
//        }else if (valor.contains("xml")){
//        //          XML
//            XStream xstr = new XStream();
//            xstr.alias("empresa", Empresa.class);
//            String xml = xstr.toXML(empresas);
//
//            response.setContentType("application/xml");
//
//            response.getWriter().print(xml);
//        
//        }else{
//            response.setContentType("application/json");
//            response.getWriter().print("{'message':'no content'}");
//        }
    }
}
